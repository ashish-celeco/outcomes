# Outcomes brand kit

Contents: outlined SVG wordmark and monogram (forest, paper and single-colour), JSON/CSS tokens, 10 transparent clay WebP assets, 8 generated application concepts, font files with their licences, reusable Astro illustration sources, and the design specifications.

The outlined logos require no installed font. Keep the terminal dot, proportions, and clear space. Use Instrument Serif for expressive display type, DM Sans for working copy, and a little monospaced caption text. Colours are RGB screen references; production suppliers should proof physical colours and fabrics.

Mockups are AI-generated visual concepts, not photographs of existing products, offices or campaigns. Exact generated typography/material appearance is illustrative; use the supplied vector logos for production. MacBook and Apple marks identify the requested device, not a brand partnership.

The HTML/CSS illustration and motion sources require the existing Astro project and shared font/tokens; they are source components, not standalone HTML files. The site at /design-system is the interactive reference. PNG generation masters and exact prompts are retained in the project docs/artwork directory.
