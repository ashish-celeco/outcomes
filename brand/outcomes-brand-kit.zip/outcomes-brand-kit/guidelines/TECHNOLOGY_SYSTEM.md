# Product illustration system

`src/components/TechnologySection.astro` presents the three products in a short editorial sequence. The product views are illustrative, not screenshots or claims about a currently shipping interface.

## Three product roles

- **Outcomes OS** — brings people, knowledge and tools into a workspace to help employees make better decisions, faster.
- **Outcomes Platform** — defines bounded agentic workflows, with human checkpoints and escalation, deployed within an organisation.
- **Outcomes Agents** — AI employees with persistent memory, goals and agreed responsibilities, available in Slack or Teams as `@outcome`.

## Visual vocabulary

The outer section uses forest `#172e24`. Cream copy panels sit beside sage (OS), lavender (Platform), and pale citron (Agents) scenes. Each scene contains a legible HTML interface on a slightly tilted surface, plus a secondary layer that explains the product's defining idea:

- OS: a decision workspace and a floating context note.
- Platform: a three-stage workflow inside a visible organisation boundary; a human review separates preparation from continuation.
- Agents: a team conversation layered over a persistent memory card and an ongoing goal.

Use actual text and CSS rather than rasterising interfaces. Content should remain editable and responsive. Do not add fabricated customer data, testimonials, performance numbers, unsupported integrations, or live product status to these examples.

## Motion and accessibility

The scene layers move a few pixels in opposite directions as their panel passes through the viewport. Movement is proportional to normal page scrolling and reverses naturally. Connector dots in the workflow follow the same progress. There are no timers, autoplay loops, scroll interception, or hidden product content.

Reduced-motion preference removes all scene transforms and movement. Without JavaScript, all three products and their complete illustrations are visible. On desktop viewports at least 1101px wide and 900px tall, the three panels form a sticky stack with each product name remaining visible as the next panel arrives. This uses ordinary CSS positioning, never scroll interception. Stacking is disabled for reduced motion, smaller windows and mobile. On smaller screens each product's copy sits above its scene. The product panels have anchors at `#technology-os`, `#technology-platform` and `#technology-agents`.
