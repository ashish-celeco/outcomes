# Selected outcomes

The five anonymised results in `src/data/case-studies.ts` were provided by the founder in the October 2026 website editing conversation. The public cards and case briefs use those metrics without inventing client names, implementation details, timelines, testimonials, or research methodology.

- Education: four times admissions in one year; deemed university with more than 8,000 students.
- Conversational commerce: 20% increase in conversion in one month; Indian sneaker brand.
- Legal: three times matters per advocate; Mumbai law practice.
- Finance: loan disbursement from two weeks to ten minutes; Maharashtra housing finance corporation.
- Retail intelligence: 35% improvement in store NPS through conversational store intelligence.

Percentage results remain percentages, not percentage points. Supplied market rankings are omitted because they add a claim without adding necessary context. Each card links to a concise case brief. These should grow into fuller case studies only when the team supplies publishable delivery details.

## Visual direction

Warm editorial collection, two large lead cards and three supporting cards. Each vertical has a recognisable `Sector / Outcomes OS` mark. A graduation cap and admission letter, a shoe and conversation bubbles, a judge’s wig and brief, a house and key, and a shopping bag with a customer’s voice provide physical visual metaphors. These are illustrative, not screenshots or reconstructed client records. Metrics remain selectable HTML text. All links work without JavaScript; gentle hover transformations respect reduced motion.

## Reusable case artwork

`src/components/CaseArtwork.astro` owns the five self-contained, decorative scenes. The public cards and brand studio should use the same component rather than copying SVG or CSS.

```astro
<CaseArtwork tone="finance" />
```

Supported `tone` values: `education`, `commerce`, `legal`, `finance`, `stores`. Default dimensions are fluid width up to 300px and a 220px scene height. Optional `compact` reduces the maximum width to 260px and height to 190px. Give the containing panel its own background. The default card backgrounds are education `#dfe6cc`, commerce `#e5dced`, legal `#efc9ab`, finance `#20382c`, stores `#e7edb7`. All styling is inside the component. Wrap studio previews in `.artwork-preview` to demonstrate hover motion; linked cards animate automatically. Reduced motion keeps the composition still.

- Education: a forest graduation cap over an ivory admission letter, with a terracotta acceptance seal.
- Commerce: the original cream-and-terracotta sneaker and two purchase conversation bubbles; retained as requested.
- Legal: an ivory judge’s wig hovering above a paper brief and terracotta folder. This is an editorial symbol for the legal profession, not a depiction of the Mumbai client or a claim about judicial dress in India.
- Finance: a dimensional ivory house, terracotta roof, citron key and small ten-minute seal. The card retains the explicit loan-disbursement metric so the illustration does not imply that a whole mortgage originates in ten minutes.
- Stores: an ivory shopping bag paired with a smiling conversational bubble; the customer’s voice is the focal point.

The illustrations use restrained forest outlines, warm paper tones and soft directional shadows. They are decorative (`aria-hidden`) because all claims and labels appear as accessible text in the surrounding card. They require no JavaScript or external asset requests.
