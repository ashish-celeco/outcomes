# Outcomes workbench illustration system

This is the saved specification for the three illustrated service panels the user selected. The source is deliberately reusable: these are HTML/CSS compositions, not flattened generated images.

## Source of truth

- `src/components/WorkIllustration.astro`: three scene variants, `workshop`, `discovery`, `deployment`.
- `src/components/Offering.astro`: each scene with its matching service label, headline, and paragraph.
- `src/styles/chapter-three.css`: the core materials, dimensions, shadows, and responsive layouts.
- `src/styles/chapter-four.css`: variant backgrounds and current type refinements.
- `/design-system`: live examples of the same components used on the homepage.

## Material and palette

| Material | Colour | Use |
| --- | --- | --- |
| Warm paper | `#fffaf0` | Primary sheets, document fronts, workflow steps |
| Sand | `#e8dfc9` | Workshop background |
| Sage | `#dce6df` | Discovery background |
| Lavender | `#e8e3f0` | Deployment background |
| Forest | `#20382c` | One focal object or active step |
| Citron | `#e4ff85` | A note, number, or small emphasis |
| Peach | `#f6be94` | Secondary sticky note |

Use two or three overlapping surfaces. Leave enough empty space to see their silhouettes. Paper is rectangular with minimal rounding; application surfaces have 4–8 px corners. Keep the foreground sharper and its shadow stronger than the background. Shadows fall downward: approximately 0 15–30 px, low opacity, warm or forest-tinted.

## Composition

The desktop scene is approximately 340 px high. Each illustration must work at 280–400 px wide. Layers rotate independently between −12° and +10°. Avoid rotating readable paragraphs. One object carries the main message, another establishes context, and a small detail makes the scene feel handled: a pencil, a note, a connector, or a review indicator.

1. **Workshop**: layered paper, a question, two task ideas, one pencil. The caption explains hands-on workshops and hackathons.
2. **Discovery**: workflow notes and hand-offs behind a foreground question, “Where does the work get stuck?” The caption explains conversations and mapping the actual work. Do not describe this panel as knowledge search while the illustration depicts workflow discovery.
3. **Deployment**: three connected steps from request, through AI preparation, to human review. The caption explains building applications and supporting adoption. This is an example workflow, not a claim that a specific customer product exists.

Use Instrument Serif for the editorial question and DM Sans for notes and interface fragments. Monospaced labels should be brief. Real HTML text keeps all wording editable and available to assistive technology. Purely decorative sheets and connectors are hidden from screen readers.

## Motion

On hover, separate sheets by 4–9 px and reduce or slightly increase their tilt. Use 450–500 ms easing. Let the objects move in relation to one another. Do not float the entire scene indefinitely. Reduced-motion preferences remove the transitions. All meaning must remain clear in a still frame and without JavaScript.

## Editorial contract

Every panel must answer the same question in three places: what its image shows, what its headline promises, and what its paragraph explains. Keep each paragraph to the relevant service. Do not add numerical improvements, customer evidence, or product claims unless supplied by the company.

## Extending the system

Start with a familiar piece of work: a hand-off, an approval, a draft, a meeting note. Build its silhouette from paper and simple interface parts. Choose one foreground action. Reuse the palette and shadows above. Add a new component variant only when its story differs from the existing three. Avoid decorative dashboards or charts with invented data.

Optional image-generation brief for a future companion object: “A single familiar work object, matte paper or painted wood, cream, muted sage, one citron or terracotta accent; warm upper-left light, soft downward shadow, slight three-quarter angle, whole object visible, transparent background, no embedded text.” Compose the final scene and text in HTML so it remains editable.
