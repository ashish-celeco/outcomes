# Outcomes Deployment Company — design system v1

## Brand character

Thoughtful, capable, warm, and particular. A team that understands both people and systems. The visual identity should feel like a well-made object: simple from a distance, rewarding up close.

**Core idea:** potential becomes useful when it is connected to real work.

**Primary action:** Book a discovery call. Use the existing founding-team Google Calendar destination in `src/data/site.ts`. Never display a false submission or booking confirmation; the booking is completed on Google's page.

## Identity

- Wordmark: lowercase `outcomes.` in Instrument Serif, with the full stop in terracotta.
- Descriptor: `DEPLOYMENT COMPANY`, uppercase with tracked monospaced lettering.
- Primary wordmark minimum: 120 px wide. Do not stretch or condense it.
- Monogram: the lowercase `o.`. Use in editorial moments and the footer, not as a substitute for an accessible company name.
- The favicon uses an original ring-and-dot drawing in the brand palette.
- In text, use “Outcomes Deployment Company.” The relationship to Celeco Labs is stated in the FAQ and footer.

## Color tokens

| Token | Value | Role |
| --- | --- | --- |
| Paper | `#f5f3e9` | Main page surface |
| Paper light | `#fcfbf7` | Process content surface |
| Ink / green | `#20382c` | Text, primary buttons, conviction section |
| Deep green | `#182c23` | Footer |
| Soft ink | `#536052` | Supporting text |
| Citron | `#e2e9a2` | Invitation surface, green-section emphasis |
| Orange | `#d86b48` | Sculpture palette, wordmark dot, decorative accents |
| Rust | `#9d402c` | Emphasized text on paper, focus outlines |
| Rule | `#d6d9c9` | Dividers and diagram structure |

Keep orange for decorative accents; use the darker rust for small text. Use green text on citron and paper, and paper/citron text on green. Avoid pale text on pale surfaces. All new color combinations need contrast verification.

## Typography

All fonts are self-hosted from their open-source npm packages.

| Role | Typeface | Behavior |
| --- | --- | --- |
| Display / wordmark | Instrument Serif regular | Light, large, tightly composed |
| Expressive emphasis | Instrument Serif italic | One short phrase within a heading |
| Body / interface | DM Sans Variable | Clear supporting explanation and controls |
| Figure labels | Courier New / monospace | Short uppercase captions only |

- Hero: 72–116 px on desktop; fluid 59–84 px on mobile; approximately 0.98 line height.
- Section headings: 48–78 px desktop, 43–52 px mobile.
- Method panel headings: 34–43 px.
- Body: 13–16 px, 1.65–1.9 line height; lead statements 21–23 px.
- Captions are deliberately small and supplemental. Never place essential instructions or critical content only in a caption.
- Keep prose to comfortable line lengths, normally under 70 characters.
- Italics signal an idea worth dwelling on. They should not appear in every sentence.

## Layout and rhythm

- Maximum content width: 1440 px.
- Desktop gutter: fluid, approximately 5.2 vw. Tablet: 32 px. Mobile: 24 px.
- Major section spacing: 112 px desktop, 80 px tablet, 65 px mobile.
- Use horizontal rules, varied compositions, and changes of surface to organize the page.
- Hero: asymmetrical text/art composition, with image caption and thin lower navigation row.
- Context: two-column prose and a connected-work diagram.
- Conviction: full-width green field, expansive serif type, restrained line geometry.
- Method: five keyboard-accessible tabs above an image/content panel.
- People: three real profiles, collapsing to a single column on mobile.
- FAQ: native disclosure elements.
- Closing CTA: citron field, prominent serif invitation, one primary action.
- Most containers have square edges. Buttons use a 3 px radius. Rounded shapes belong primarily to the artwork and identity.

## Component behavior

### Buttons and links

Primary: green fill, paper text, diagonal arrow, minimum 52–56 px tall. Header CTA uses citron. External booking links open a new tab with `noopener noreferrer`. Hover shifts the arrow a few pixels and changes the fill subtly. Focus is always visible.

Secondary: plain text with an underline/rule and arrow. Anchor links navigate to the relevant section; there are no empty `href` values or placeholder actions.

### Process explorer

Roles: `tablist`, `tab`, `tabpanel`. One selected tab and one visible panel after enhancement. Left/right arrows cycle; Home/End jump to endpoints. Clicking the next-stage action changes the panel and moves focus to the selected tab. All five panels are present and readable if JavaScript is unavailable.

### Navigation

Desktop shows three section links. Mobile uses an explicit toggle with `aria-expanded` and `aria-controls`. Escape closes it and restores focus. Selecting a link or clicking outside closes it. A no-JavaScript navigation fallback remains available.

### FAQ

Use native `details`/`summary`, so the content remains accessible and interactive without JavaScript. Multiple answers can stay open, allowing comparison.

## Artwork direction

### The material language

Matte painted wood, ceramic, warm cream stone, slight tactile grain, and believable directional light. Architecture at the scale of a tabletop model. The visual metaphor is a connected path, not machinery or a humanoid robot.

Use two or three main materials per composition. Limit each object to the brand palette. Preserve ample negative space and clear silhouettes. Transparent backgrounds let the forms sit naturally on multiple brand surfaces.

### Artwork inventory

1. `public/images/potential.webp` — a terracotta O, cream path/staircase, green supporting block, and small green sphere. Hero artwork. Original generated at 1536 × 1024; served at 1400 px wide in WebP with alpha.
2. `public/images/practice.webp` — a green portal, cream support and steps, and a terracotta sphere. Method artwork. Original generated at 1254 × 1254; served at 900 px wide in WebP with alpha.
3. Founder portraits — the actual images embedded on Celeco Labs, converted to WebP. CSS applies a restrained duotone presentation; hover returns some natural color.

Both sculptures were created specifically for this project using ImageGen. Generated originals are retained in `docs/artwork/`. They are illustrative brand imagery, not photographs of company work or evidence of deployments.

### Reusable prompt pattern

> An editorial still-life for Outcomes Deployment Company. One freestanding architectural assemblage about [specific business idea]. Matte handcrafted ceramic and painted wood, tactile grain, cream #efe6bd, terracotta #d9613c, forest green #203d30. Simple structural silhouettes with meaningful negative space. Warm daylight from upper left, elevated three-quarter camera, believable material and contact shading. Fully isolated on transparent background with generous margins. No text, no logo, no scenery, no glowing effects, no glossy toy plastic.

Keep the object count low. Use the existing artwork as a visual reference for future commissions. Review edges on both light and dark surfaces. Never crop away the part of the form that explains the metaphor.

## Motion

- Native scrolling; no scroll hijacking or pinned narratives.
- One short hero image arrival; subtle section reveals.
- Hover transitions: 200–250 ms; reveals: 700 ms.
- Easing: `cubic-bezier(.22,.61,.36,1)`.
- No infinite animation, video background, loading spectacle, or cursor replacement.
- `prefers-reduced-motion` disables animation/transitions and smooth scrolling.
- Content remains visible without script support; reveal styles are applied only when a working observer is available.

## Accessibility and performance

- Semantic landmarks, one primary heading, meaningful labels, real buttons and links.
- Skip link, visible keyboard focus, keyboard tabs, Escape handling, native disclosures.
- Decorative icons are hidden from assistive technology; images have meaningful alternative text.
- Only the hero image loads eagerly. Other images have dimensions and lazy loading.
- All fonts and imagery are local; no analytics, tracking scripts, or runtime third-party asset requests.
- Astro generates static HTML. The whole site is readable without JavaScript.
- Validate 320 px, 390 px, tablet, and desktop widths; no horizontal page overflow.
- Check automated accessibility plus keyboard and visual behavior. Automated scans alone do not certify accessibility.

## Editorial rules

- Explain what the company does in concrete terms.
- Preserve the original five-stage service and named deliverables.
- Distinguish technology capabilities from partnerships and customer relationships.
- Use real team credentials from Celeco, with no embellished titles or outcomes.
- Do not introduce invented client logos, testimonials, savings, revenue, timelines, or pricing.
- Use “Book a discovery call” consistently for the primary action.
- Update `src/data/site.ts` when the offer, team, or booking destination changes.

## Launch configuration

Set `PUBLIC_SITE_URL` to the final HTTPS domain when known. The static build then emits canonical URLs and a complete social-image URL. The brand is implemented as the requested launch direction; domain configuration and public deployment remain separate steps.

## Version 2: space, light, and motion

The homepage now uses a dark forest opening (#14291f), warm paper (#f8f5ec), electric citron (#e4ff85), and a bold terracotta careers invitation (#bc4527). The serif wordmark and its dot remain. Instrument Serif carries larger, overlapping headlines, with DM Sans for explanations.

The opening separates moving light, grain, orbital lines, transparent clay artwork, and foreground content. Slow looping movement keeps the scene alive; passive scroll events schedule a single animation frame to change depth. The luminous middle ring changes perspective as it passes through the viewport. A pause control stops ambient motion; system reduced-motion preferences disable it. No scroll hijacking or timed automatic tab changes.

Five chapters use five separate transparent WebP compositions: doorway / education, magnifying glass / discovery, branching path / roadmap, exploded assembly / infrastructure, ring and path / deployment. Switching stages animates the new illustration and copy, changes the background, and preserves accessible keyboard tabs. PNG masters are in `docs/artwork`.

The careers page shares the same materials with a lighter opening. Its copy is based on the founder conversation and public Celeco careers page. Avoid invented roles, salary ranges, clients, numerical results, or promises about the hiring process.

Copy editing follows the Humanizer skill linked in `research-v2/NOTES.md`. Prefer a concrete observation from everyday work to a slogan. Aspirational headlines need nearby copy that explains what the company does.

## Version 3: Outcomes, explained through objects

The public name is now **Outcomes**. Remove the descriptor from wordmarks, page titles, metadata, footers, and social cards. Keep historical company references to Celeco Labs where they explain the relationship or application destination.

The existing landing composition and curved foreground remain. The first screen explicitly introduces AI transformation. The next section states the offering before the method, with three illustrative compositions: workshop/people capability, documents and answers/company knowledge, request-to-review/applications and adoption. These are examples, not product screenshots or customer results. A new original connected clay sculpture explains the relationship between people, knowledge, tools, and AI. Additional transparent art continues through careers, FAQ, and contact.

A 1.9-second O. introduction opens through an expanding circular aperture into the hero. It is cosmetic and never traps focus or blocks interaction; pointer, wheel, touch, or keyboard input dismisses it. Deep links and reduced-motion preferences skip it. The page stays visible without JavaScript. A timeout clears the entrance class even if an animation event fails.

The pause-motion and scroll-to-explore UI were removed as requested. Ambient animations now settle after four seconds; scroll depth and deliberate hover/tab transitions remain. The O. sequence does not delay image loading or render the content conditionally. Layer-specific additions live in `src/styles/chapter-three.css`.

## Version 4: identity in motion, work in view

The headline is “AI transformation. Measured in outcomes.” The offering below it follows a consistent sequence: workshops, understanding the work, building and adoption. Image, label, headline, and paragraph must describe the same service.

The selected paper/interface illustration language is now a reusable component system. See **ILLUSTRATION_SYSTEM.md** for the saved construction specification and the live `/design-system` page for examples rendered from the same source as the homepage. `WorkIllustration.astro` supplies each scene; `Offering.astro` pairs it with the copy.

The O. entrance has been replaced: the dot lands, letters assemble into Outcomes, the wordmark moves into the header, and five staggered panels lift to reveal the page. There is no aperture or zoom-through. Interaction, reduced motion, and deep links retain their bypass behavior. The full sequence finishes in about 2.8 seconds.

The method is now a full-width editorial journey on native scroll. Large sticky clay artwork accompanies five always-present chapters. Sage, peach, lavender, sea green, and citron backgrounds mark progress. A numbered anchor index provides direct navigation; there are no tab boxes. Mobile uses a shorter sticky scene; no-JavaScript rendering shows each chapter’s own image.

Thirteen provider logos form a large horizontal rail. Users can swipe, drag, use arrow buttons, or focus the rail and use the keyboard. Entry motion is finite; no perpetual marquee or pause control. Sarvam’s wordmark comes from its official public asset; the other marks are from the MIT-licensed LobeHub icon collection. See research-v4/NOTES.md for provenance and reference observations.

## Bespoke business scene — October 2026

The former abstract connected-platform image is replaced by three independent clay objects: collaborators, a computer, and an archive. `BespokeSystem.astro` composes them with HTML labels and scroll-drawn SVG connections around a dimensional cream panel. The headline is “Works your way. Belongs to you.” Intelligence and IP ownership is explicit. See [BESPOKE_SCENE.md](BESPOKE_SCENE.md) for the exact image-generation prompts, source assets, responsive composition, accessibility, and motion contract. The established workshop/discovery/deployment illustration system remains the reference for those service panels.

## Technology, client outcomes, and people — October 2026

- `TechnologySection.astro`: three product scenes—decision workspace, governed workflow, and a persistent Slack/Teams agent. Taller desktop screens use a scroll stack with all product names retained; mobile and reduced motion use normal flow. The scenes are labelled as illustrative product views.
- `CaseStudies.astro`: a two-lead/three-supporting editorial grid with distinct vertical Outcomes OS marks, metric typography, and editable SVG/paper props. Five linked anonymised case briefs retain the founder-supplied metrics. Content lives in `src/data/case-studies.ts`.
- `TeamSection.astro`: monochrome portraits, layered backing sheets, floating serif nameplates, and subtle pointer/entry movement. The new Ashish portrait is an AI-prepared derivative of the supplied attachment; provenance is documented in `TEAM_PORTRAITS.md`.
- `BespokeSystem.astro`: the centrepiece is now a clay brain. A finite settling animation, scroll-linked movement, and small pointer shifts bring the objects to life. Ownership wording: “Intelligence we build. Owned by your organisation.”

Specifications: `TECHNOLOGY_SYSTEM.md`, `CASE_STUDIES.md`, `TEAM_PORTRAITS.md`, and the updated `BESPOKE_SCENE.md`. Existing workbench illustrations remain unchanged.
