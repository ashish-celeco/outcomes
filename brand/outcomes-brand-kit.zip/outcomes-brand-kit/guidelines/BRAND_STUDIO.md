# Outcomes Brand Studio

The internal `/design-system` route is the working reference for the brand. It has `noindex, nofollow` metadata and is not linked from the public navigation. This makes it unlisted, not access controlled; deployment access is a separate decision.

## Source of truth

- `src/pages/design-system.astro`: identity, voice, palette, typography, illustration library, interface specimens, downloads, and editorial layout.
- `src/components/BrandMotionLab.astro`: three finite, manually replayable motion examples.
- `src/components/BrandApplications.astro`: photographic brand application concepts.
- `src/components/WorkIllustration.astro` through `Offering.astro`: the same three paper compositions as the homepage.
- `src/components/CaseArtwork.astro`: the same five industry illustrations as the customer stories.
- Existing `Wordmark.astro`, font packages, and clay assets are reused directly.

## Included tools

1. Eight exact colour values, each with a copy button and an accessible fallback when clipboard access is unavailable.
2. A type playground with editable sample text, font family/style selection, and a 32–96 px size range.
3. A ten-object clay library with paper, forest, and citron background previews.
4. Three replay buttons demonstrating the signature, paper layers, and a clay connection. All movements finish within two seconds and honour reduced motion, including a preference change after page load.
5. Real interface specimens with keyboard focus and clear status messages.
6. Brand kit ZIP and tokens JSON download links, supplied by the central asset bundle.

## Editorial rules

Warm and specific. Explain the work, the people involved, and the next step. Keep evidence proportional to the claim. Never invent customer results or use mockups as evidence of real installations. The applications are visual concepts.

Forest and warm paper dominate. Citron accents an invitation. Terracotta carries warmth in objects and the dot; use darker rust for coloured text on paper. Instrument Serif leads; DM Sans explains; Courier New provides short technical captions.

The logo specimens describe recommended working clear space and minimum sizes. Keep the supplied proportions and dot. The brand is Outcomes, without a company descriptor.

## Access and accessibility

The page works as a readable reference without JavaScript. JavaScript adds the optional tools. Sticky navigation scrolls horizontally at narrow widths; no content is hidden behind it. All images are local and use the shared base-path helper. Text remains real HTML outside generated artwork. Application concepts and supplied client evidence remain distinct.

## Validation — October 3, 2026

The studio (excluding the separately owned application gallery) passed axe with no violations at 1440, 390, and 320 px. No horizontal overflow or JavaScript errors were observed. The type sample, font selector, size slider, colour copying, denied-clipboard fallback, and clay backdrop selector were exercised. All three replay examples start and finish; changing to reduced motion stops a running example. Without JavaScript, all eight chapters, ten clay images, three workbench scenes, and five industry scenes remain present at 320 px without overflow. Main Astro build passed.

Visual references are saved under `docs/screenshots/brand-*`. Application mockups and download assets are validated separately once their bundle is complete.

## Applications and downloadable material

`BrandApplications.astro` includes eight generated concepts: canvas totes, an Apple MacBook with stickers, T-shirts/hoodie/cap, a welcome kit, an office, a metro campaign, a bus-shelter campaign, and stationery. The gallery supports category filters, a native-dialog full-screen view, keyboard previous/next, Escape, focus restoration, and image downloads. The entire composition is visible in the viewer. Without JavaScript, each image links directly to its full-size file.

Original generation masters and exact prompts: `docs/artwork/brand/`. Web assets: `public/brand/mockups/`. These are concept visuals, not evidence of manufactured merchandise or existing ad placements. Actual print artwork should use the supplied SVG logos; the device brand does not imply a partnership.

Downloads:

- `public/brand/outcomes-brand-book.pdf`: 16-page landscape field guide including all eight mockups.
- `public/brand/outcomes-brand-kit.zip`: six outlined SVG logos, JSON/CSS tokens, ten transparent clay artworks, eight mockups, the PDF book, font files/licences, shared illustration component sources, and written guidance.
- `public/brand/outcomes-tokens.json` and `.css`: colour, type, spacing, motion and material references.

To regenerate assets, run from the repository root (Python FontTools, Sharp and Chromium are available in the configured environment):

```sh
python3 scripts/brand-assets.py
node scripts/brand-print-images.mjs
node scripts/brand-book.cjs
python3 scripts/brand-assets.py
```

Keep the brand studio out of the public navigation. `noindex` is indexing guidance, not access control. Public publication of the expanded internal studio is pending the founder's choice of unlisted review page versus restricted access.


## Offline review and public build

`.releases/outcomes-brand-studio.zip` contains the complete studio and its downloads. Extract it and open `index.html`; CSS and fonts are embedded, images and downloadable files use relative paths, and scripts have no module imports. The bundled page was also checked through a local HTTP server: all 21 images loaded, gallery enhancement initialized, and no runtime errors occurred. This environment's browser policy blocks `file://` navigation, so direct-file opening could not be automated here.

Regenerate the offline package after a root-path build with `python3 scripts/brand-offline.py`. Use `python3 scripts/build-public.py` for public releases while access remains undecided. It excludes the expanded studio and `/brand/` assets, preserves the earlier public guide, and restores source files in a `finally` block.
