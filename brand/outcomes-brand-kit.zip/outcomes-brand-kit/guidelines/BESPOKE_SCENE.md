# Bespoke business scene

Component: `src/components/BespokeSystem.astro`.

The scene explains a specific offer: Outcomes designs and deploys bespoke AI around an organisation's people, tools, processes, and knowledge. The intelligence and IP created belong to that organisation. This ownership statement comes directly from the company's founder, supplied for this section.

## Composition

Three independent transparent clay objects surround a terracotta clay brain on an ivory plinth. People collaborate around a table, a filing cabinet holds accumulated knowledge, and a desktop computer represents everyday tools. SVG paths connect all three to bespoke AI; the caption identifies those connections as the way work flows. The brain represents intelligence built around the customer’s organisation; its real HTML label reads “Bespoke AI / Built for you.”

Labels and all explanatory text remain HTML. The figure has a descriptive accessible caption. Its decorative images use empty alt text because their roles are named by the adjacent labels. No information depends on animation.

## Image generation recipe

Shared prompt: “Create one standalone sculptural illustration for Outcomes, a sophisticated AI transformation studio. Transparent background, whole object visible with 8% breathing room, square composition. Handcrafted matte clay with subtle tactile grain, rounded but refined edges, restrained editorial design, warm light from upper left, three-quarter view from slightly above, orthographic camera, front and right side visible. Palette only warm ivory #efe6bd, terracotta #d9613c, forest green #203d30. No text, no logos, no surrounding scene, no floor plane, no enclosing box. Real physical handmade clay model, not shiny plastic.”

Object-specific prompts:

- **People:** “A group of three abstract human clay figures gathered around a small round ivory worktable with two little sheets of paper. One seated green figure, one standing terracotta figure, one ivory figure. Recognisably people with heads, bodies and arms; faceless, sculptural, different heights. Warm sense of collaboration. Entire table and all figures visible, tightly composed.”
- **Tools:** “A single beautiful chunky ivory desktop computer with forest green screen, a simple terracotta circle and two ivory horizontal interface lines on screen, an ivory keyboard with tactile keys and small terracotta mouse in front. A minimalist low ivory plinth under computer keyboard and mouse. This must read immediately as a real computer made entirely of clay, quiet charming retro-futurist shape.”
- **Knowledge:** “A single forest green two-drawer filing cabinet with chunky ivory handles. Top drawer pulled slightly open revealing several ivory and terracotta file folders, and a small neat stack of ivory paper sheets on top with one terracotta notebook. Recognisably an archive of company knowledge. Entire cabinet visible including its base. No writing.”

ImageGen masters are saved at `docs/artwork/business-{people,tools,knowledge,brain}.png`. Web assets are 600 × 600 transparent WebP files,  in `public/images/`. Keep the masters. Future objects should use the same palette, camera, texture, and lighting, with labels added in HTML rather than baked into an image.

## Motion

The scene assembles as it enters the viewport. The objects move inward, the paths draw, and gentle scroll-linked movement continues as the reader passes through the section. A single 4.6-second settling animation adds a little life on entry; it does not loop. Mouse movement shifts the objects by a few pixels. Resizing recalculates progress. Reduced motion removes all entry, pointer, and scroll movement. Disabled JavaScript shows a complete still scene. The brain, computer, and labels have separate vertical space on mobile.

## Editorial

Headline: “Works your way. Belongs to you.” The paragraph explains what bespoke means, and the ownership statement uses the founder’s exact revision: “Intelligence we build. Owned by your organisation.” Do not turn these claims into guarantees about third-party model ownership, data residency, or vendor partnerships.


## Brain prompt

“A standalone sculptural brain for a refined AI studio website, transparent background. Whole object visible with 8% breathing room in a square composition. A beautiful warm terracotta clay brain (#d9613c) resting on a low warm ivory (#efe6bd) rounded oval plinth. Brain recognisable as two softly folded hemispheres, simplified sculptural broad folds, welcoming and thoughtful, not anatomical gore, no veins, no eyes, no face. Handcrafted matte clay subtle tactile grain, refined rounded edges. Three-quarter view from slightly above, orthographic camera, front and right side visible, warm studio light upper left. Palette only terracotta and ivory. One small forest-green inset disc on the front of the plinth, no writing or logos. No background, no floor, no surrounding objects. Premium editorial physical clay sculpture, not shiny plastic.”
